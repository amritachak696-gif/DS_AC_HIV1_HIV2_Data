import pickle
import numpy as np
import networkx as nx
from collections import defaultdict
import dash
from dash import dcc, html
import dash_cytoscape as cyto

# ---------- INPUT FILES ----------
with open("HIV2_apo.pkl", "rb") as f:
    contact_freq, atom_info = pickle.load(f)   # atom_info = (resname, resid, atom_name)

corr_matrix = np.loadtxt("Final_CorrelationMatrix_HIV2_apo.dat")

# ---------- GRAPH CONSTRUCTION ----------
n_atoms = len(atom_info)
G = nx.DiGraph()

for i, (resname, resid, atom_name) in enumerate(atom_info):
    G.add_node(i, resname=resname, resid=resid, atom=atom_name)

contact_thresh = 0.5
epsilon = 1e-8

for i in range(n_atoms):
    for j in range(i + 1, n_atoms):
        cf = contact_freq[i][j]
        rho = corr_matrix[i][j]
        if cf > contact_thresh:
            weight = -np.log(abs(rho) + epsilon)  # correlation-based weight
            G.add_edge(i, j, weight=weight)

# ---------- SOURCE & TARGET (ATOM ID RANGE) ----------
source_range = (154, 193)
target_range = (282, 412)

source_nodes = [i for i in range(n_atoms) if source_range[0] <= i <= source_range[1]]
target_nodes = [i for i in range(n_atoms) if target_range[0] <= i <= target_range[1]]

if not source_nodes:
    print(f"⚠️ No source atoms found in atom index range {source_range}")
if not target_nodes:
    print(f"⚠️ No target atoms found in atom index range {target_range}")

# ---------- SHORTEST PATHS & RELAY COUNTS ----------
relay_counter = defaultdict(int)
all_paths = []

for src in source_nodes:
    for tgt in target_nodes:
        try:
            path = nx.shortest_path(G, source=src, target=tgt, weight="weight")
            all_paths.append(path)
            for node in path[1:-1]:  # exclude src & tgt
                relay_counter[node] += 1
        except nx.NetworkXNoPath:
            continue

# ---------- NORMALIZE COUNTS ----------
total_count = sum(relay_counter.values())
relay_weights = {node: count / total_count for node, count in relay_counter.items()} if total_count > 0 else {}

# ---------- TOP 30 RELAY ATOMS ----------
top_n = 30
sorted_relays = sorted(relay_weights.items(), key=lambda x: x[1], reverse=True)[:top_n]

# ---------- RESIDUE-LEVEL AGGREGATION ----------
residue_weights = defaultdict(float)
atom_to_residue = {}
for atom_idx, (resname, resid, atom_name) in enumerate(atom_info):
    atom_to_residue[atom_idx] = (resname, resid)

for atom_idx, weight in relay_weights.items():
    resname, resid = atom_to_residue[atom_idx]
    residue_weights[(resname, resid)] += weight

sorted_residues = sorted(residue_weights.items(), key=lambda x: x[1], reverse=True)[:top_n]

# ---------- BUILD RESIDUE-LEVEL GRAPH ----------
H = nx.Graph()
for (resname, resid), score in sorted_residues:
    H.add_node(f"{resname}{resid}", weight=score)

for i, j, data in G.edges(data=True):
    res_i = atom_to_residue[i]
    res_j = atom_to_residue[j]
    if res_i in dict(sorted_residues) and res_j in dict(sorted_residues):
        node_i = f"{res_i[0]}{res_i[1]}"
        node_j = f"{res_j[0]}{res_j[1]}"
        if node_i != node_j:
            if H.has_edge(node_i, node_j):
                H[node_i][node_j]["weight"] += 1
            else:
                H.add_edge(node_i, node_j, weight=1)

# ---------- CYTOSCAPE ELEMENTS ----------
elements = []

# ---------- Add nodes ----------
for node, data in H.nodes(data=True):
    elements.append({
        "data": {
            "id": node,
            "label": node,
            "weight": data["weight"]  # <-- node weight (relay score)
        }
    })

# ---------- Add edges ----------
for u, v, d in H.edges(data=True):
    elements.append({
        "data": {
            "id": f"{u}-{v}",        # optional: give edges an id
            "source": u,
            "target": v,
            "weight": d["weight"]    # <-- edge weight
        }
    })
    
    
# ---------- DASH APP ----------
app = dash.Dash(__name__)

app.layout = html.Div([
    html.H1("Residue-Level Relay Network (Interactive)"),
    cyto.Cytoscape(
        id="cytoscape-network",
        layout={"name": "cose"},   # force-directed layout
        style={"width": "100%", "height": "800px"},
        elements=elements,
        stylesheet=[
            # Node styling
            {
                "selector": "node",
                "style": {
                    "label": "data(label)",
                    "width": "mapData(weight, 0, 0.1, 20, 80)",  # scale size by relay score
                    "height": "mapData(weight, 0, 0.1, 20, 80)",
                    "background-color": "mapData(weight, 0, 0.1, lightblue, red)",
                    "font-size": "14px"
                }
            },
            # Edge styling
            {
                "selector": "edge",
                "style": {
                    "width": "mapData(weight, 0, 10, 1, 8)",  # <-- scale edge thickness by weight
                    "line-color": "#888",
                    "curve-style": "bezier"
                }
            },
            # Selected element styling
            {
                "selector": ":selected",
                "style": {
                    "border-width": 3,
                    "border-color": "black"
                }
            }
        ],
        userZoomingEnabled=True,
        userPanningEnabled=True,
        boxSelectionEnabled=True,
        autounselectify=False,
        responsive=True,
    )
])

if __name__ == "__main__":
    app.run_server(debug=True)
