import pandas as pd
import numpy as np

# Function to process the input file
def process_file(file_name, pc_column, top_n):
    # Use sep='\s+' instead of deprecated 'delim_whitespace=True'
    df = pd.read_csv(file_name, sep=r'\s+', header=None, names=['Feature', pc_column], engine='python')

    # Compute absolute values
    abs_col = f'{pc_column}_Abs'
    df[abs_col] = df[pc_column].abs()

    # Sort and extract top N
    sorted_df = df.sort_values(by=abs_col, ascending=False)
    top_df = sorted_df.head(top_n)

    return top_df

# Set number of top residue pairs to extract
top_n = 5  # Change this value if needed

# Process PC3 and PC4 files
top_pc3 = process_file('header-col-pc3-col.dat', 'PC3_Value', top_n)
top_pc4 = process_file('header-col-pc4-col.dat', 'PC4_Value', top_n)

# Save top residue pairs
top_pc3.to_csv('top_residue_pairs_pc3.csv', index=False)
top_pc4.to_csv('top_residue_pairs_pc4.csv', index=False)

# Print results
print("✅ Top residue pairs based on PC3:")
print(top_pc3[['Feature', 'PC3_Value', 'PC3_Value_Abs']])

print("\n✅ Top residue pairs based on PC4:")
print(top_pc4[['Feature', 'PC4_Value', 'PC4_Value_Abs']])
