import pyemma
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from pyemma.coordinates.data import FeatureReader

# ─── 1. User inputs ─────────────────────────────────────────────────────────────
raw_traj  = '1anr_APO_RNA_Heavyatoms_100ns_to_960ns_noPBC.xtc'
gro_file  = '1anr_APO_RNA_Heavyatoms_Single_Frame.gro'
cutoff_nm = 0.5

# ─── 2. Parse GRO to preserve original residue numbering ───────────────────────
resid_map = []
with open(gro_file, 'r') as f:
    lines = f.readlines()
for line in lines[2:-1]:
    try:
        resid = int(line[0:5].strip())
    except ValueError:
        continue
    if not resid_map or resid_map[-1] != resid:
        resid_map.append(resid)
n_res = len(resid_map)

# ─── 3. Set up PyEMMA featurizer (trajectory is already unwrapped) ─────────────
feat = pyemma.coordinates.featurizer(gro_file)
residue_pairs = [(i, j) for i in range(n_res) for j in range(i + 1, n_res)]
feat.add_residue_mindist(
    residue_pairs=residue_pairs,
    scheme='closest-heavy',
    ignore_nonprotein=False,
    periodic=False  # trajectory already preprocessed (no PBC)
)

# ─── 4. Load trajectory in chunks using FeatureReader ───────────────────────────
reader = FeatureReader(raw_traj, featurizer=feat)
n_frames = reader.n_frames_total()

print(f"⏳ Reading {n_frames} frames and converting to binary contact maps...")

# Load the full trajectory output as a list of arrays (one frame per row)
frames = reader.get_output()[0]  # shape = (n_frames, n_pairs)

# Convert all distances to binary contact maps
binary_maps = (frames <= cutoff_nm).astype(np.uint8)  # shape = (n_frames, n_pairs)

# ─── 5. Run PCA ────────────────────────────────────────────────────────────────
pca = PCA()
pca.fit(binary_maps)
eigenvectors = pca.components_

# ─── 6. Save Outputs ───────────────────────────────────────────────────────────
np.savetxt("eigenvectors.csv", eigenvectors, delimiter=",")

pair_names = [f"{resid_map[i]}-{resid_map[j]}" for (i, j) in residue_pairs]
pd.Series(pair_names).to_csv("header.csv", index=False, header=False)

print("✅ Contact-PCA complete. Outputs saved:")
print("   - eigenvectors.csv")
print("   - header.csv")
