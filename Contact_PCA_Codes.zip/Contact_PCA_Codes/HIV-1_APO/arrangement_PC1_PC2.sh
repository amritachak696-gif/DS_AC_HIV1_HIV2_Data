#!/bin/bash

# Extract PC1 and PC2 from eigenvectors.csv
head -1 eigenvectors.csv > pc1.dat
head -2 eigenvectors.csv | tail -1 > pc2.dat

# Convert comma-separated values to line-separated
tr ',' '\n' < pc1.dat > pc1-col.dat
tr ',' '\n' < pc2.dat > pc2-col.dat

# Combine with header.csv
paste header.csv pc1-col.dat > header-col-pc1-col.dat
paste header.csv pc2-col.dat > header-col-pc2-col.dat

echo "✅ Output files:"
echo "   - header-col-pc1-col.dat"
echo "   - header-col-pc2-col.dat"
