#!/bin/bash

# Extract the 3rd principal component (PC3) line from eigenvectors.csv
head -3 eigenvectors.csv | tail -1 > pc3.dat

# Extract the 4th principal component (PC4) line from eigenvectors.csv
head -4 eigenvectors.csv | tail -1 > pc4.dat

# Convert comma-separated values to one-per-line for PC3 and PC4
tr ',' '\n' < pc3.dat > pc3-col.dat
tr ',' '\n' < pc4.dat > pc4-col.dat

# Combine header.csv with PC3 and PC4 component values
paste header.csv pc3-col.dat > header-col-pc3-col.dat
paste header.csv pc4-col.dat > header-col-pc4-col.dat
