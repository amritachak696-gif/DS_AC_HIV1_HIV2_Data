import pyemma
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from pyemma.coordinates.data import FeatureReader
import matplotlib.pyplot as plt
import seaborn as sns

# 🔹 Add this immediately after matplotlib/seaborn imports
import matplotlib as mpl
mpl.rcParams['pdf.fonttype'] = 42
mpl.rcParams['ps.fonttype'] = 42

# ---- 1. User inputs ----
raw_traj  = '6mce_APO_RNA_Heavyatoms_150ns_to_1us_noPBC.xtc'
gro_file  = '6mce_APO_RNA_Heavyatoms_Single_Frame.gro'
cutoff_nm = 0.5

# ---- 2. Parse GRO to preserve original residue numbering ----
resid_map = []
with open(gro_file, 'r') as f:
    lines = f.readlines()
for line in lines[2:-1]:
    try:
        resid = int(line[0:5].strip())
    except ValueError:
        continue
    if not resid_map or resid_map[-1] != resid:
        resid_map.append(resid)
n_res = len(resid_map)

# ---- 3. Set up PyEMMA featurizer ----
feat = pyemma.coordinates.featurizer(gro_file)
residue_pairs = [(i, j) for i in range(n_res) for j in range(i + 1, n_res)]
feat.add_residue_mindist(
    residue_pairs=residue_pairs,
    scheme='closest-heavy',
    ignore_nonprotein=False,
    periodic=False
)

# ---- 4. Load trajectory data ----
reader = FeatureReader(raw_traj, featurizer=feat)
n_frames = reader.n_frames_total()
print(f"⏳ Reading {n_frames} frames and converting to binary contact maps...")
frames = reader.get_output()[0]
binary_maps = (frames <= cutoff_nm).astype(np.uint8)

# ---- 5. Run PCA ----
pca = PCA()
pca.fit(binary_maps)
eigenvectors = pca.components_

# ---- 6. Analyze PC1 weights ----
pc1 = eigenvectors[0]  # take the first principal component
abs_pc1 = np.abs(pc1)

pair_names = [f"{resid_map[i]}-{resid_map[j]}" for (i, j) in residue_pairs]

# Get indices of top-5 by absolute weight (1D sorting)
top5_idx = np.argsort(abs_pc1)[-5:][::-1]

print("\nTop 5 residue pairs (by |PC1 weight|):")
for idx in top5_idx:
    print(f"{pair_names[idx]} : {pc1[idx]:.4f}")

# ---- 7. Construct residue-residue matrix for heatmap ----
pc1_matrix = np.full((n_res, n_res), np.nan)
for idx, (i, j) in enumerate(residue_pairs):
    # symmetric assignment of absolute PC1 weights to both (i,j) and (j,i)
    pc1_matrix[i, j] = abs_pc1[idx]
    pc1_matrix[j, i] = abs_pc1[idx]

# ---- 8. Mask lower triangle (including diagonal) ----
mask = np.tril(np.ones_like(pc1_matrix, dtype=bool), k=0)

# --- 9. Plot heatmap with formatting and side axes ---
from mpl_toolkits.axes_grid1 import make_axes_locatable

fontname = "Times New Roman"
axis_fontsize = 26
label_fontsize = 29
cb_fontsize = 26
#title_fontsize = 24

resid_start = 16
tick_step = 2
tick_positions = list(range(0, n_res, tick_step))
tick_labels = [str(resid_start + x) for x in tick_positions]

# ---- Switch for box around heatmap ----
show_box   = False       # 🔹 True = show box, False = hide box
box_color  = "black"    # 🔹 color of the box (e.g., "black", "red", "blue")
box_width  = 0.25        # 🔹 thickness of the box lines

fig, ax = plt.subplots(figsize=(12, 10), dpi=600)

# Create the heatmap without automatic colorbar
hm = sns.heatmap(
    pc1_matrix,
    mask=mask,
    cmap=sns.color_palette("coolwarm", as_cmap=True),
    square=True,
    xticklabels=False,
    yticklabels=False,
    cbar=False,   # disable seaborn's default cbar
    linewidths=0.0,
    ax=ax
)

# Invert y-axis so that bottom-left corresponds to the starting residue index
ax.invert_yaxis()

# Bottom x-axis ticks/labels
ax.set_xticks(tick_positions)
ax.set_xticklabels(tick_labels, fontname=fontname, fontsize=axis_fontsize)
ax.xaxis.tick_bottom()
ax.set_xlabel('RNA Residue Index', fontname=fontname, fontsize=label_fontsize, labelpad=12)

# Right y-axis ticks/labels
ax.yaxis.tick_right()
ax.set_yticks(tick_positions)
ax.set_yticklabels(tick_labels, fontname=fontname, fontsize=axis_fontsize)
ax.set_ylabel('RNA Residue Index', fontname=fontname, fontsize=label_fontsize, labelpad=12)
ax.yaxis.set_label_position("right")

# Hide left y-axis and top x-axis ticks
ax.tick_params(axis='y', which='both', left=False)
ax.tick_params(axis='x', which='both', top=False)

# ---- Control box visibility, color, and thickness ----
if show_box:
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(box_width)
        spine.set_edgecolor(box_color)
else:
    for spine in ax.spines.values():
        spine.set_visible(False)

# ---- Create top colorbar with adjustable size ----
divider = make_axes_locatable(ax)
cax = divider.append_axes("top", size="5%", pad=0.6)  # size and pad adjustable
cbar = fig.colorbar(hm.collections[0], cax=cax, orientation='horizontal')

cbar.set_label('|Weight Value of Residue Pairs along PC1|', fontname=fontname, fontsize=cb_fontsize, labelpad=8)
cbar.ax.xaxis.set_ticks_position('top')
cbar.ax.xaxis.set_label_position('top')
cbar.ax.tick_params(labelsize=cb_fontsize)
for label in cbar.ax.get_xticklabels():
    label.set_fontname(fontname)
    label.set_fontsize(cb_fontsize)

plt.tight_layout()
plt.savefig("Weighted_Contact_Pairs_along_PC1_Upper_HIV2_APO_Resnr16.tiff", dpi=600, bbox_inches='tight')
plt.savefig("Weighted_Contact_Pairs_along_PC1_Upper_HIV2_APO_Resnr16.pdf", dpi=600, bbox_inches='tight')
plt.show()
