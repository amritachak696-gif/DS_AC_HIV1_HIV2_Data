import pandas as pd
import numpy as np

# Function to process the input file
def process_file(file_name, pc_column, top_n):
    # Use sep='\s+' to handle any whitespace delimiter (space or tab)
    df = pd.read_csv(file_name, sep=r'\s+', header=None, names=['Feature', pc_column], engine='python')

    # Compute absolute values
    abs_col = f'{pc_column}_Abs'
    df[abs_col] = df[pc_column].abs()

    # Sort and extract top N
    sorted_df = df.sort_values(by=abs_col, ascending=False)
    top_df = sorted_df.head(top_n)

    return top_df

# Number of top residue pairs to extract
top_n = 30  # You can change this

# Process PC1 and PC2 files
top_pc1 = process_file('header-col-pc1-col.dat', 'PC1_Value', top_n)
top_pc2 = process_file('header-col-pc2-col.dat', 'PC2_Value', top_n)

# Save results
top_pc1.to_csv('top_residue_pairs_pc1.csv', index=False)
top_pc2.to_csv('top_residue_pairs_pc2.csv', index=False)

# Print results
print("✅ Top residue pairs based on PC1:")
print(top_pc1[['Feature', 'PC1_Value', 'PC1_Value_Abs']])

print("\n✅ Top residue pairs based on PC2:")
print(top_pc2[['Feature', 'PC2_Value', 'PC2_Value_Abs']])
